120mm pc fan to 4" drier duct by MajorHardware on Thingiverse: https://www.thingiverse.com/thing:3887692

Summary:
this will allow your 120mm pc fan to attach to 4" drier ducting 
